import java.util.Scanner;

// Base class
class Publication {
    protected String title;
    protected float price;

    // Method to get data from the user
    public void getData() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter title: ");
        this.title = scanner.nextLine();

        try {
            System.out.print("Enter price: $");
            this.price = Float.parseFloat(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input for price. Setting price to 0.0");
            this.price = 0.0f;
        }
    }

    // Method to display data
    public void displayData() {
        System.out.println("Title: " + title);
        System.out.println("Price: $" + price);
    }
}

// Derived class for books
class Book extends Publication {
    private int pageCount;

    // Overridden method to get data specific to books
    @Override
    public void getData() {
        super.getData(); // Call the base class method to get common data

        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter page count: ");
            this.pageCount = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input for page count. Setting page count to 0");
            this.pageCount = 0;
        }
    }

    // Overridden method to display book-specific data
    @Override
    public void displayData() {
        super.displayData(); // Call the base class method to display common data
        System.out.println("Page Count: " + pageCount);
    }
}

// Derived class for tapes
class Tape extends Publication {
    private float playingTime;

    // Overridden method to get data specific to tapes
    @Override
    public void getData() {
        super.getData(); // Call the base class method to get common data

        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter playing time (in minutes): ");
            this.playingTime = Float.parseFloat(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input for playing time. Setting playing time to 0.0");
            this.playingTime = 0.0f;
        }
    }

    // Overridden method to display tape-specific data
    @Override
    public void displayData() {
        super.displayData(); // Call the base class method to display common data
        System.out.println("Playing Time: " + playingTime + " minutes");
    }
}

// Main class
public class Main {
    public static void main(String[] args) {
        // Instantiate objects of the derived classes
        Book book = new Book();
        Tape tape = new Tape();

        // Get and display data for book
        System.out.println("Enter book details:");
        book.getData();
        System.out.println("\nBook details:");
        book.displayData();

        // Get and display data for tape
        System.out.println("\nEnter tape details:");
        tape.getData();
        System.out.println("\nTape details:");
        tape.displayData();
    }
}
